<?php
    $order          = $module->order;
    $product        = $module->product;
    $LANG           = $module->lang;