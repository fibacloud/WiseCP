<?php
    return [
        'type'                          => "virtualization",
        'access-hash'                   => false,
        'server-info-checker'           => false,
        'server-info-port'              => false,
        'configurable-option-params'    => [
            'Products',
            'OS' => 'Operating System',
        ],
    ];